CHANGELOG
=========

5.1.0
-----

 * The component has been deprecated, use `EnglishInflector` from the String component instead.
