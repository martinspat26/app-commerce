<?php

return [
    'Names' => [
        'DJF' => [
            0 => 'Fdj',
            1 => 'franc djiboutien',
        ],
    ],
];
