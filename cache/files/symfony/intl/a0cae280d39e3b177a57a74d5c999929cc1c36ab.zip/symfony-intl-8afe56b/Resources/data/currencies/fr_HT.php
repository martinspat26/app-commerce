<?php

return [
    'Names' => [
        'HTG' => [
            0 => 'G',
            1 => 'gourde haïtienne',
        ],
    ],
];
