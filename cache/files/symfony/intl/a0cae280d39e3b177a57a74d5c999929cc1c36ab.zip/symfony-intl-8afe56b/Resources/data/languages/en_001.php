<?php

return [
    'Names' => [
        'bla' => 'Siksika',
        'mus' => 'Creek',
    ],
    'LocalizedNames' => [
        'nds_NL' => 'West Low German',
    ],
];
