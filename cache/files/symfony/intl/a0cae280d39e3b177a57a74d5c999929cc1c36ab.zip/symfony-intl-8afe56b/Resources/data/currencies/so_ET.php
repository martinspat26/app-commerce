<?php

return [
    'Names' => [
        'ETB' => [
            0 => 'Br',
            1 => 'Birta Itoobbiya',
        ],
    ],
];
