<?php

return [
    'Names' => [
        'MKD' => [
            0 => 'den',
            1 => 'Denari maqedonas',
        ],
    ],
];
