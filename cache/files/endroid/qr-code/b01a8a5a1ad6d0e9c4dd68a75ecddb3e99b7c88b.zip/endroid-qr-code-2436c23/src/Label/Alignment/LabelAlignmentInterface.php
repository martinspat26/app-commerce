<?php

declare(strict_types=1);

namespace Endroid\QrCode\Label\Alignment;

interface LabelAlignmentInterface
{
}
