<?php

namespace Laminas\Code\Exception;

interface ExceptionInterface
{
}
