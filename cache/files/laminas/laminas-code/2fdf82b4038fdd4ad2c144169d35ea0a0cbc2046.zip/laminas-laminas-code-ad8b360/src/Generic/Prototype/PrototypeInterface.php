<?php

namespace Laminas\Code\Generic\Prototype;

/** @internal this class is not part of the public API of this package */
interface PrototypeInterface
{
    /**
     * @return string
     */
    public function getName();
}
