SensioFrameworkExtraBundle
==========================

**WARNING**: SensioFrameworkExtraBundle is not maintained anymore.
Please move to native PHP attribute support as added in Symfony core.
For full support, use [Symfony 6.2](https://symfony.com/blog/new-in-symfony-6-2-built-in-cache-security-template-and-doctrine-attributes).

This bundle provides a way to configure your controllers with annotations.

Read about it on its [official homepage](http://symfony.com/doc/current/bundles/SensioFrameworkExtraBundle/index.html).
